┌───────────────────────────────────────┐
│ 10 Undetermined Supply Chain Findings │
└───────────────────────────────────────┘
                                            
    blogWeb/package-lock.json
    ❯❱ @babel/runtime - CVE-2025-27789
          Severity: MODERATE                                                                    
          Affected versions of @babel/helpers, @babel/runtime, @babel/runtime-corejs2, and @babel/runtime-
          corejs3 are vulnerable to Inefficient Regular Expression Complexity.                            
                                                                                                          
           ▶▶┆ Fixed for @babel/runtime at versions: 7.26.10, 8.0.0-alpha.17
          308┆ "node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime": {
   
    ❯❱ vite - CVE-2025-31486
          Severity: MODERATE                                                                    
          Affected versions of vite are vulnerable to Exposure of Sensitive Information to an Unauthorized
          Actor / Improper Access Control.                                                                
                                                                                                          
           ▶▶┆ Fixed for vite at versions: 4.5.12, 5.4.17, 6.0.14, 6.1.4, 6.2.5
          1060┆ "node_modules/@angular/build/node_modules/vite": {
   
    ❯❱ vite - CVE-2025-30208
          Severity: MODERATE                                                                    
          Affected versions of vite are vulnerable to Exposure of Sensitive Information to an Unauthorized
          Actor / Improper Access Control.                                                                
                                                                                                          
           ▶▶┆ Fixed for vite at versions: 4.5.10, 5.4.15, 6.0.12, 6.1.2, 6.2.3
          1060┆ "node_modules/@angular/build/node_modules/vite": {
   
    ❯❱ vite - CVE-2025-31125
          Severity: MODERATE                                                                   
          Affected versions of vite are vulnerable to Exposure of Sensitive Information to an Unauthorized
          Actor / Improper Access Control.                                                                
                                                                                                          
          ▶▶┆ Fixed for vite at versions: 4.5.11, 5.4.16, 6.0.13, 6.1.3, 6.2.4
          1060┆ "node_modules/@angular/build/node_modules/vite": {
   
    ❯❱ vite - CVE-2025-32395
          Severity: MODERATE                                                                    
          Affected versions of vite are vulnerable to Exposure of Sensitive Information to an Unauthorized
          Actor.                                                                                          
                                                                                                          
          ▶▶┆ Fixed for vite at versions: 4.5.13, 5.4.18, 6.0.15, 6.1.5, 6.2.6
          1060┆ "node_modules/@angular/build/node_modules/vite": {
   
    ❯❱ vite - CVE-2025-46565
          Severity: MODERATE                                                                 
          Affected versions of vite are vulnerable to Improper Limitation of a Pathname to a Restricted
          Directory ('Path Traversal').                                                                
                                                                                                       
          ▶▶┆ Fixed for vite at versions: 4.5.14, 5.4.19, 6.1.6, 6.2.7, 6.3.4
          1060┆ "node_modules/@angular/build/node_modules/vite": {
   
    ❯❱ esbuild - GHSA-67mh-4wv8-2f99
          Severity: MODERATE                                       
          Affected versions of esbuild are vulnerable to Origin Validation Error.
                                                                                 
           ▶▶┆ Fixed for esbuild at version: 0.25.0
          1131┆ "node_modules/@angular/build/node_modules/vite/node_modules/esbuild": {
   
    ❯❱ http-proxy-middleware - CVE-2025-32997
          Severity: MODERATE                                                            
          Affected versions of http-proxy-middleware are vulnerable to Improper Check for Unusual or
          Exceptional Conditions.                                                                   
                                                                                                    
          ▶▶┆ Fixed for http-proxy-middleware at versions: 2.0.9, 3.0.5
          9225┆ "node_modules/http-proxy-middleware": {
   
    ❯❱ http-proxy-middleware - CVE-2025-32996
          Severity: MODERATE                                                          
          Affected versions of http-proxy-middleware are vulnerable to Always-Incorrect Control Flow
          Implementation.                                                                           
                                                                                                    
           ▶▶┆ Fixed for http-proxy-middleware at versions: 2.0.8, 3.0.4
          9225┆ "node_modules/http-proxy-middleware": {
   
    ❯❱ vite - CVE-2025-46565
          Severity: MODERATE                                                               
          Affected versions of vite are vulnerable to Improper Limitation of a Pathname to a Restricted
          Directory ('Path Traversal').                                                                
                                                                                                       
           ▶▶┆ Fixed for vite at versions: 4.5.14, 5.4.19, 6.1.6, 6.2.7, 6.3.4
          14053┆ "node_modules/vite": {

