package com.socialApp.blogServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
