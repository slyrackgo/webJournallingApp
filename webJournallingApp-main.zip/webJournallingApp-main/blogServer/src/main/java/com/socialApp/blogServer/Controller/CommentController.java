package com.socialApp.blogServer.Controller;

import com.socialApp.blogServer.Service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.apache.commons.text.StringEscapeUtils;

@RestController
@RequestMapping("/api/")
@CrossOrigin
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("comments/create")
    public ResponseEntity<?> createComment(
            @RequestParam Long postId,
            @RequestParam String postedBy,
            @RequestParam String content) {
        try {
            // Simple input validation and sanitization
            if (postedBy.length() > 100 || content.length() > 1000) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Input too long.");
            }

            String sanitizedPostedBy = StringEscapeUtils.escapeHtml4(postedBy);
            String sanitizedContent = StringEscapeUtils.escapeHtml4(content);

            return ResponseEntity.ok(commentService.createComment(postId, sanitizedPostedBy, sanitizedContent));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Unable to create comment.");
        }
    }

    @GetMapping("comments/{postId}")
    public ResponseEntity<?> getCommentbyPostId(@PathVariable Long postId) {
        try {
            if (postId < 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid post ID.");
            }
            return ResponseEntity.ok(commentService.getCommentByPostId(postId));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong.");
        }
    }
}
