
# Security Fixes and Improvements

---

## 1. auth.service.ts

**Issue:**  
Plaintext credentials were used, exposing sensitive data.

**Fixes:**  
- Passwords are now encoded with Base64 before verification.  
- Random JWT token generation implemented instead of using a static `"fake-jwt-token"`.  
- Switched token storage from `localStorage` to `sessionStorage` to improve session security.

---

## 2. application.properties

**Issue:**  
Hardcoded database credentials were present in the configuration file:  
```properties
spring.datasource.password=290903@a
```  
This is insecure and exposes sensitive information in version control or shared environments.

**Fix:**  
Replaced the hardcoded password with a dynamic environment variable:  
```properties
spring.datasource.password=${DB_PASSWORD:defaultPassword}
```  

**Benefits:**  
- Secure handling of credentials via environment variables.  
- Default fallback password for local development if the environment variable is not set.

**Usage:**  
To set the environment variable and run the application after the fix:  
```bash
export DB_PASSWORD=290903@a
./mvnw spring-boot:run
```

---

## 3. PostController.java

**Issue:**  
The method `public ResponseEntity<?> getPostById(@PathVariable Long postId)` had vulnerabilities including:  
- IDOR (Insecure Direct Object Reference)  
- Potential SQL injection  
- Lack of input validation  

**Fix Summary:**  
- Added basic input validation to ensure only valid IDs are processed.  
- Improved error handling to give safe and consistent responses.  
- Sanitized search input parameters to avoid injection attacks.  
- Cleaned and standardized response formats.

---

## 4. CommentController.java

**Fix Summary:**  
- Sanitized all user inputs using `escapeHtml4` to prevent Cross-Site Scripting (XSS).  
- Added input length validation checks to avoid input abuse and buffer overflow.  
- Improved handling of invalid or malformed `postId` parameters.  
- Simplified error messages to prevent leaking stack traces or sensitive server information.

---

*End of documentation.*
