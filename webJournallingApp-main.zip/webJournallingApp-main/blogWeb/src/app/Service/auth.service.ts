import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);

  constructor(private router: Router) {}

  // Simulated user database (password still in base64 for simplicity)
  private users = [
    { email: 'user@example.com', password: btoa('superSecurePassword123') },
  ];

  // Login method
  login(credentials: { email: string; password: string }) {
    const encodedPassword = btoa(credentials.password);
    const user = this.users.find(
      (u) => u.email === credentials.email && u.password === encodedPassword
    );

    if (user) {
      // Use sessionStorage consistently
      const fakeToken = Math.random().toString(36).substring(2); // simple fake token
      sessionStorage.setItem('token', fakeToken);
      this.loggedIn.next(true);
      this.router.navigate(['/view-all']);
    } else {
      alert('Invalid email or password');
    }
  }

  // Logout method
  logout() {
    sessionStorage.removeItem('token'); // Correct storage
    this.loggedIn.next(false);
    this.router.navigate(['/login']);
  }

  // Check if the user is logged in
  isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  // Get the fake JWT token
  getToken() {
    return sessionStorage.getItem('token'); // Consistent with login/logout
  }
}
